(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.OURS_SEARCH = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const normalize = value => String(value ?? '').normalize('NFKC').toLocaleLowerCase()
    .replace(/[\s.\/年月日-]/g, '');
  const text = value => {
    if (Array.isArray(value)) return value.map(text).join(' ');
    if (value && typeof value === 'object') return Object.values(value).map(text).join(' ');
    return String(value ?? '');
  };
  function indexEvent(event, photos) {
    const date = event.date || '';
    const dateParts = date.split('-').map(Number);
    const aliases = [date, dateParts.join(''), dateParts.slice(1).join('')];
    return normalize([
      ...aliases, event.title, event.place, event.description, text(event.notes),
      ...photos.filter(photo => photo.eventId === event.id)
        .flatMap(photo => [photo.caption, photo.city, photo.date])
    ].filter(Boolean).join(' '));
  }
  function matches(index, query) {
    const tokens = String(query || '').trim().split(/\s+/).map(normalize).filter(Boolean);
    return tokens.every(token => index.includes(token));
  }
  function shouldSubmit(event, composing, sinceCompositionEnd = Infinity) {
    return event.key === 'Enter' && !event.isComposing && event.keyCode !== 229
      && !composing && sinceCompositionEnd > 160;
  }
  return { normalize, indexEvent, matches, shouldSubmit };
});
