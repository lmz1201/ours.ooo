/* A lightweight textured paper surface. CSS strips remain the fallback. */
window.OURS_PAPER_SURFACE = (() => {
  const vertexSource = `
    attribute vec2 a_uv;
    uniform vec2 u_card;
    uniform vec2 u_size;
    uniform vec2 u_pad;
    uniform float u_progress;
    varying vec2 v_tex;
    varying float v_face;
    void main() {
      float globalP = u_progress;
      float diagonal = sin(globalP * 3.1415926);
      float p = clamp(globalP + (a_uv.x - 0.5) * 0.27 * diagonal, 0.0, 1.0);
      float bend = 2.85 * sin(p * 1.5707963);
      float stepSize = a_uv.y / 24.0;
      vec2 arc = vec2(0.0);
      for (int i = 0; i < 24; i++) {
        float along = (float(i) + 0.5) * stepSize;
        float theta = p * 0.45 + bend * pow(along, 1.55) + (a_uv.x - 0.5) * along * diagonal * 0.28;
        arc += vec2(cos(theta), sin(theta)) * stepSize * u_card.y;
      }
      float theta = p * 0.45 + bend * pow(a_uv.y, 1.55) + (a_uv.x - 0.5) * a_uv.y * diagonal * 0.28;
      float fall = pow(max(0.0, (p - 0.42) / 0.58), 2.0) * u_card.y * 0.65;
      float scale = 900.0 / (900.0 - arc.y);
      float x = u_pad.x + u_card.x * 0.5 + (a_uv.x - 0.5) * u_card.x * scale;
      x += diagonal * u_card.x * 0.14 * pow(a_uv.y, 1.7) * (0.6 + a_uv.x * 0.4);
      float y = u_pad.y + (arc.x - u_card.y * 0.1) * scale + u_card.y * 0.1 + fall;
      y += (a_uv.x - 0.5) * diagonal * u_card.y * 0.08 * pow(a_uv.y, 1.8);
      gl_Position = vec4(x / u_size.x * 2.0 - 1.0, 1.0 - y / u_size.y * 2.0, -arc.y / 700.0, 1.0);
      v_tex = vec2(a_uv.x, 1.0 - a_uv.y);
      v_face = cos(theta);
    }`;
  const fragmentSource = `
    precision mediump float;
    uniform sampler2D u_tex;
    uniform float u_opacity;
    varying vec2 v_tex;
    varying float v_face;
    void main() {
      vec4 ink = texture2D(u_tex, v_tex);
      vec3 paperBack = vec3(0.985, 0.942, 0.866);
      vec3 color = v_face >= 0.0 ? ink.rgb : paperBack;
      color *= 0.86 + 0.14 * abs(v_face);
      gl_FragColor = vec4(color, ink.a * u_opacity);
    }`;

  function create(card) {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl', {alpha:true, antialias:true, depth:true, premultipliedAlpha:false});
    if (!gl) return null;
    function shader(type, source) {
      const result = gl.createShader(type);
      gl.shaderSource(result, source);
      gl.compileShader(result);
      if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) throw new Error('Paper shader unavailable');
      return result;
    }
    try {
      const program = gl.createProgram();
      gl.attachShader(program, shader(gl.VERTEX_SHADER, vertexSource));
      gl.attachShader(program, shader(gl.FRAGMENT_SHADER, fragmentSource));
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return null;
      gl.useProgram(program);
      const points=[], triangles=[], columns=12, rows=80;
      for (let row=0;row<=rows;row++) for (let column=0;column<=columns;column++) points.push(column/columns,row/rows);
      for (let row=0;row<rows;row++) for (let column=0;column<columns;column++) {
        const a=row*(columns+1)+column, b=a+1, c=a+columns+1, d=c+1;
        triangles.push(a,c,b,b,c,d);
      }
      gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(points),gl.STATIC_DRAW);
      const attribute=gl.getAttribLocation(program,'a_uv');
      gl.enableVertexAttribArray(attribute);
      gl.vertexAttribPointer(attribute,2,gl.FLOAT,false,0,0);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,gl.createBuffer());
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(triangles),gl.STATIC_DRAW);
      const uniform=name=>gl.getUniformLocation(program,name);
      const uniforms={card:uniform('u_card'),size:uniform('u_size'),pad:uniform('u_pad'),progress:uniform('u_progress'),opacity:uniform('u_opacity')};
      const texture=gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.LEQUAL);
      canvas.className='curl-surface';
      canvas.setAttribute('aria-hidden','true');
      const leaf=card.querySelector('.curled-leaf');
      leaf.append(canvas);
      leaf.querySelectorAll('.paper-strip').forEach(strip=>{strip.hidden=true;});
      function prepare(value) {
        const width=card.clientWidth,height=card.clientHeight;
        const padX=Math.ceil(width*.3),padY=Math.ceil(height*.75);
        const fullWidth=width+padX*2,fullHeight=height+padY*2;
        const dpr=Math.min(window.devicePixelRatio||1,2);
        canvas.width=Math.ceil(fullWidth*dpr);canvas.height=Math.ceil(fullHeight*dpr);
        Object.assign(canvas.style,{width:fullWidth+'px',height:fullHeight+'px',left:-padX+'px',top:-padY+'px'});
        gl.viewport(0,0,canvas.width,canvas.height);
        gl.uniform2f(uniforms.card,width,height);gl.uniform2f(uniforms.size,fullWidth,fullHeight);gl.uniform2f(uniforms.pad,padX,padY);
        const source=document.createElement('canvas');
        source.width=Math.ceil(width*dpr);source.height=Math.ceil(height*dpr);
        const context=source.getContext('2d');
        context.scale(dpr,dpr);
        const background=context.createLinearGradient(0,0,0,height);
        background.addColorStop(0,'#fbf0dd');background.addColorStop(1,'#f8e9d0');
        context.fillStyle=background;context.beginPath();context.roundRect(0,0,width,height,5);context.fill();
        const style=getComputedStyle(card.querySelector('.digit-value'));
        context.font=`${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
        context.textAlign='center';context.textBaseline='alphabetic';context.fillStyle=style.color;
        if ('letterSpacing' in context) context.letterSpacing=style.letterSpacing;
        const metrics=context.measureText(value);
        const size=parseFloat(style.fontSize);
        const ascent=metrics.fontBoundingBoxAscent||size*.8,descent=metrics.fontBoundingBoxDescent||size*.2;
        context.fillText(value,width/2,(height-ascent-descent)/2+ascent);
        gl.bindTexture(gl.TEXTURE_2D,texture);
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);
      }
      function draw(progress) {
        gl.uniform1f(uniforms.progress,progress);
        gl.uniform1f(uniforms.opacity,progress>=1?0:progress<.66?1:1-(progress-.66)/.34);
        gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
        gl.drawElements(gl.TRIANGLES,triangles.length,gl.UNSIGNED_SHORT,0);
      }
      return {prepare,draw};
    } catch (_) { return null; }
  }
  return {create};
})();
