(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.OURS_PAPER = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function width(total) {
    return Math.max(3, String(Math.max(0, Math.floor(total))).length);
  }
  function plan(total) {
    if (total <= 0) return [{value:0,delay:0,duration:0}];
    return Array.from({ length: total }, (_, index) => {
      const value = index + 1;
      const remaining = total - value;
      const delay = Math.round(4 + 220 * Math.exp(-remaining / 8));
      return {
        value,
        delay,
        duration: Math.max(2, Math.round(delay * 0.78))
      };
    });
  }
  function profile(progress, width, height, count = 16) {
    const p = Math.max(0, Math.min(1, progress));
    const segment = height / count;
    const bend = 2.85 * Math.sin(p * Math.PI / 2);
    const fall = p <= 0.42 ? 0 : ((p - 0.42) / 0.58) ** 2 * height * 0.65;
    const opacity = p >= 1 ? 0 : p < 0.66 ? 1 : Math.max(0, 1 - (p - 0.66) / 0.34);
    let y = 0, z = 0;
    const strips = [];
    for (let index = 0; index < count; index++) {
      const ratio = (index + 0.5) / count;
      const angle = p * 0.45 + bend * ratio ** 1.55;
      const front = Math.cos(angle) >= 0;
      strips.push({
        y: y + fall - index * segment,
        z,
        x: Math.sin(p * Math.PI) * width * 0.14 * ratio ** 1.7,
        angle: angle * 180 / Math.PI,
        ink: Math.max(0, Math.min(1, (Math.PI / 2 - angle) / 0.25)),
        shade: front ? 0.91 + 0.09 * Math.cos(angle) : 0.96
      });
      y += segment * Math.cos(angle);
      z += segment * Math.sin(angle);
    }
    return { opacity, strips };
  }
  return { plan, profile, width };
});
