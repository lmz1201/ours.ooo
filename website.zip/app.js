(() => {
  'use strict';
  const data = window.OURS_DATA;
  const photos = data.photos || [];
  const stars = data.stars || [];
  const events = [...data.events].sort((a, b) => a.date.localeCompare(b.date));
  const $ = selector => document.querySelector(selector);
  const make = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const stamp = value => {
    const [year, month, day] = value.split('-').map(Number);
    return Date.UTC(year, month - 1, day);
  };
  const now = new Date();
  const year = now.getFullYear();
  const today = Date.UTC(year, now.getMonth(), now.getDate());
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const image = photo => {
    const img = make('img');
    img.src = photo.src;
    img.alt = photo.caption;
    img.loading = 'lazy';
    return img;
  };
  const coverFor = id => photos.find(p => p.eventId === id && p.cover)
    || photos.find(p => p.eventId === id && p.hero)
    || photos.find(p => p.eventId === id);

  // Start at 000, then turn the number cards until they reach today's count.
  const totalDays = Math.max(0, Math.floor((today - stamp(data.togetherSince)) / 86400000) + 1);
  const counter = $('#together-days');
  const paper = window.OURS_PAPER;
  const digitCount = paper.width(totalDays);
  counter.dataset.digits = String(digitCount);
  counter.style.setProperty('--count-vw', `${Math.min(28, 65 / (digitCount * 0.68))}vw`);
  const paperAnimations = new WeakMap();
  const paperSurfaces = new WeakMap();
  const stripCount = 48;
  counter.setAttribute('aria-label', `${totalDays} 天`);
  counter.title = '在一起当天为第 1 天';
  const digits = Array.from({ length: digitCount }, () => {
    const card = make('span', 'flip-digit');
    card.setAttribute('aria-hidden', 'true');
    const leaf = make('span', 'flip-leaf curled-leaf');
    for (let index = 0; index < stripCount; index++) {
      const strip = make('span', 'paper-strip');
      strip.append(make('span', 'paper-text', '0'));
      leaf.append(strip);
    }
    card.append(make('span', 'digit-value', '0'), leaf);
    counter.append(card);
    return card;
  });
  function stopPaper(card) {
    const frame = paperAnimations.get(card);
    if (frame !== undefined) cancelAnimationFrame(frame);
    paperAnimations.delete(card);
    card.querySelector('.flip-leaf').style.opacity = '0';
  }
  function curlPaper(card, oldValue, duration) {
    stopPaper(card);
    const leaf = card.querySelector('.flip-leaf');
    if (!paperSurfaces.has(card)) paperSurfaces.set(card, window.OURS_PAPER_SURFACE.create(card));
    const surface = paperSurfaces.get(card);
    if (surface) {
      surface.prepare(oldValue);
      const began = performance.now();
      leaf.style.opacity = '1';
      function render(at) {
        const progress = Math.min(1, (at - began) / duration);
        surface.draw(progress);
        if (progress < 1) paperAnimations.set(card, requestAnimationFrame(render));
        else stopPaper(card);
      }
      render(began);
      return;
    }
    const strips = Array.from(leaf.children);
    const width = card.clientWidth;
    const height = card.clientHeight;
    const segment = height / stripCount;
    strips.forEach((strip, index) => {
      strip.style.top = `${segment * index}px`;
      strip.style.height = `${segment + 1.1}px`;
      const face = strip.firstElementChild;
      face.textContent = oldValue;
      face.style.top = `${-segment * index}px`;
      face.style.height = `${height}px`;
      face.style.lineHeight = `${height}px`;
    });
    const began = performance.now();
    function draw(at) {
      const progress = Math.min(1, (at - began) / duration);
      const frame = paper.profile(progress, width, height, stripCount);
      leaf.style.opacity = String(frame.opacity);
      strips.forEach((strip, index) => {
        const position = frame.strips[index];
        strip.style.transform = `translate3d(${position.x}px,${position.y}px,${position.z}px) rotateX(${position.angle}deg)`;
        strip.style.backgroundColor = `rgb(${Math.round(251 * position.shade)},${Math.round(239 * position.shade)},${Math.round(220 * position.shade)})`;
        strip.firstElementChild.style.opacity = String(position.ink);
      });
      if (progress < 1) paperAnimations.set(card, requestAnimationFrame(draw));
      else stopPaper(card);
    }
    draw(began);
  }
  function setCounter(value, animate, duration = 300) {
    const text = String(value).padStart(digitCount, '0');
    counter.dataset.value = text;
    digits.forEach((card, index) => {
      const base = card.querySelector('.digit-value');
      if (base.textContent === text[index]) return;
      const oldValue = base.textContent;
      base.textContent = text[index];
      // All places involved in a carry must settle before the next increment.
      if (animate && duration >= 24) curlPaper(card, oldValue, duration);
      else stopPaper(card);
    });
  }
  function animateDays() {
    if (reduceMotion) { setCounter(totalDays, false); return; }
    const steps = paper.plan(totalDays);
    function next(index) {
      if (index >= steps.length) return;
      const step = steps[index];
      setTimeout(() => {
        setCounter(step.value, true, step.duration);
        next(index + 1);
      }, step.delay);
    }
    setTimeout(() => next(0), 150);
  }

  const lightbox = $('#lightbox');
  let currentPhotos = [];
  let currentPhotoIndex = 0;
  function showPhoto() {
    const photo = currentPhotos[currentPhotoIndex];
    if (!photo) return;
    const img = lightbox.querySelector('img');
    img.src = photo.src;
    img.alt = photo.caption;
    lightbox.querySelector('figcaption').textContent = `${photo.caption}${photo.date ? ' · ' + photo.date : ''}　${currentPhotoIndex + 1} / ${currentPhotos.length}`;
    lightbox.querySelectorAll('.lightbox-prev,.lightbox-next').forEach(button => {
      button.hidden = currentPhotos.length < 2;
    });
  }
  function openPhoto(photo, group) {
    currentPhotos = group;
    currentPhotoIndex = group.indexOf(photo);
    showPhoto();
    if (!lightbox.open) lightbox.showModal();
  }
  function movePhoto(delta) {
    if (!currentPhotos.length) return;
    currentPhotoIndex = (currentPhotoIndex + delta + currentPhotos.length) % currentPhotos.length;
    showPhoto();
  }
  lightbox.querySelector('.dialog-close').addEventListener('click', () => lightbox.close());
  lightbox.querySelector('.lightbox-prev').addEventListener('click', () => movePhoto(-1));
  lightbox.querySelector('.lightbox-next').addEventListener('click', () => movePhoto(1));
  lightbox.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') { event.preventDefault(); movePhoto(-1); }
    if (event.key === 'ArrowRight') { event.preventDefault(); movePhoto(1); }
  });
  lightbox.addEventListener('click', event => { if (event.target === lightbox) lightbox.close(); });

  const detailDialog = $('#event-dialog');
  detailDialog.querySelector('.dialog-close').addEventListener('click', () => detailDialog.close());
  detailDialog.addEventListener('click', event => { if (event.target === detailDialog) detailDialog.close(); });
  function openDetail(event) {
    const root = $('#event-detail');
    root.replaceChildren();
    const heading = make('h2', '', event.title);
    heading.id = 'detail-title';
    root.append(make('p', 'event-detail-date', event.date.replaceAll('-', '.')), heading);
    if (event.place) root.append(make('p', 'detail-place', event.place));
    if (event.description) root.append(make('p', 'detail-description', event.description));
    for (const note of event.notes || []) root.append(make('p', 'detail-description', note));
    const group = photos.filter(photo => photo.eventId === event.id);
    if (group.length) {
      const grid = make('div', 'detail-photos');
      for (const photo of group) {
        const button = make('button', 'detail-photo');
        button.type = 'button';
        button.append(image(photo), make('p', '', `${photo.caption} · ${photo.date}`));
        button.addEventListener('click', () => openPhoto(photo, group));
        grid.append(button);
      }
      root.append(grid);
    } else root.append(make('p', 'detail-empty', '暂无照片'));
    detailDialog.showModal();
    detailDialog.scrollTop = 0;
  }

  events.forEach((event, index) => {
    const article = make('article', 'slide timeline-entry');
    article.dataset.eventId = event.id;
    article.setAttribute('aria-label', `${event.date} ${event.title}`);
    const layout = make('div', 'entry-layout');
    const visual = make('button', 'entry-visual');
    visual.type = 'button';
    visual.setAttribute('aria-label', `查看${event.title}的照片与记录`);
    const cover = coverFor(event.id);
    const group = photos.filter(photo => photo.eventId === event.id);
    if (cover) visual.append(image(cover));
    else {
      const empty = make('div', `cover-placeholder tone-${index % 6}`);
      empty.append(make('span', 'placeholder-mark', event.date.slice(5).replace('-', '.')),
        make('span', 'placeholder-caption', '暂无照片'));
      visual.append(empty);
    }
    const caption = make('div', 'visual-caption');
    caption.append(make('span', '', event.date.replaceAll('-', '.')), make('span', '', `${group.length} 张照片 ↗`));
    visual.append(caption);
    visual.addEventListener('click', () => openDetail(event));
    const copy = make('div', 'entry-copy');
    copy.append(make('div', 'entry-date', event.date.replaceAll('-', ' / ')));
    if (event.kind === 'anniversary') copy.append(make('span', 'entry-tag', '纪念日'));
    copy.append(make('h2', '', event.title));
    if (event.place && event.title !== event.place) copy.append(make('p', 'entry-place', event.place));
    const open = make('button', 'entry-open', '翻开这一天');
    open.type = 'button';
    open.append(make('span', '', '↗'));
    open.addEventListener('click', () => openDetail(event));
    copy.append(open);
    layout.append(visual, copy);
    article.append(layout);
    $('#timeline').append(article);
  });

  function annualDate(monthDay) {
    let date = stamp(`${year}-${monthDay}`);
    if (date < today) date = stamp(`${year + 1}-${monthDay}`);
    return date;
  }
  const upcoming = [
    ...events.filter(event => event.kind === 'anniversary').map(event => ({
      title: event.id === 'together' ? '恋爱纪念日'
        : event.title.endsWith('纪念日') ? event.title : event.title + '纪念日',
      date: annualDate(event.date.slice(5))
    })),
    ...(data.holidays || []).map(holiday => ({ title: holiday.title, date: annualDate(holiday.monthDay) }))
  ].sort((a, b) => a.date - b.date).slice(0, 3);
  for (const item of upcoming) {
    const row = make('div', 'upcoming-item');
    const remaining = Math.round((item.date - today) / 86400000);
    row.append(make('div', 'upcoming-date', new Date(item.date).toISOString().slice(5, 10).replace('-', '.')),
      make('h3', 'upcoming-title', item.title));
    const count = make('div', 'upcoming-stat');
    count.append(make('strong', 'upcoming-number', remaining === 0 ? '今天' : String(remaining)));
    if (remaining !== 0) count.append(make('span', 'upcoming-unit', '天后'));
    row.append(count);
    $('#upcoming').append(row);
  }

  if (!data.wishes.length) {
    const empty = make('div', 'empty-state');
    empty.append(make('span', 'empty-symbol', '○'), make('h2', '', '暂无愿望'));
    $('#wish-list').append(empty);
  }
  for (const wish of data.wishes) {
    const row = make('article', 'wish-item' + (wish.done ? ' done' : ''));
    const body = make('div');
    body.append(make('span', 'wish-text', wish.text));
    if (wish.note) body.append(make('p', 'wish-note', wish.note));
    row.append(make('span', '', wish.done ? '✓' : '○'), body);
    $('#wish-list').append(row);
  }
  $('#star-count').textContent = stars.length;
  function renderStars() {
    const query = $('#star-search').value.trim().toLocaleLowerCase();
    const filtered = stars.filter(star => star.name.toLocaleLowerCase().includes(query));
    $('#star-grid').replaceChildren();
    $('#star-empty').hidden = stars.length > 0;
    $('#star-no-results').hidden = !stars.length || filtered.length > 0;
    for (const star of filtered) {
      const card = make('button', 'star-card');
      card.type = 'button';
      const cover = star.photos.find(photo => photo.cover) || star.photos[0];
      card.append(image({ ...cover, caption: star.name }), make('h2', '', star.name),
        make('p', '', `已收藏 · ${star.photos.length} 张照片 ↗`));
      card.addEventListener('click', () => openPhoto(cover, star.photos));
      $('#star-grid').append(card);
    }
  }
  $('#star-search').addEventListener('input', renderStars);
  renderStars();

  const scroller = $('#page-home');
  const slides = Array.from(scroller.querySelectorAll('.slide'));
  let activeSlide = 0;
  let landedSlide = -1;
  let scrollAnimation = null;
  function slideTop(slide) {
    return slide.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop;
  }
  function nearestSlide() {
    let best = 0;
    let distance = Infinity;
    slides.forEach((slide, index) => {
      const delta = Math.abs(slideTop(slide) - scroller.scrollTop);
      if (delta < distance) { distance = delta; best = index; }
    });
    return best;
  }
  function updatePosition() {
    activeSlide = nearestSlide();
    $('#slide-position').textContent = String(activeSlide + 1).padStart(2, '0');
    if (Math.abs(slideTop(slides[activeSlide]) - scroller.scrollTop) < scroller.clientHeight * 0.38 && landedSlide !== activeSlide) {
      slides.forEach(slide => slide.classList.remove('is-landed'));
      slides[activeSlide].classList.add('is-landed');
      landedSlide = activeSlide;
    }
  }
  function cancelPageTurn() {
    if (scrollAnimation !== null) cancelAnimationFrame(scrollAnimation);
    scrollAnimation = null;
    scroller.classList.remove('is-turning');
  }
  function goSlide(index) {
    const target = Math.max(0, Math.min(slides.length - 1, index));
    cancelPageTurn();
    const start = scroller.scrollTop;
    const end = slideTop(slides[target]);
    const from = nearestSlide();
    if (reduceMotion || Math.abs(target - from) > 1 || Math.abs(end - start) < 2) {
      scroller.scrollTo({ top: end, behavior: 'instant' });
      updatePosition();
      return;
    }
    const began = performance.now();
    const duration = 900;
    scroller.classList.add('is-turning');
    const turn = at => {
      const t = Math.min(1, (at - began) / duration);
      const eased = t < 0.5 ? 16 * t ** 5 : 1 - (-2 * t + 2) ** 5 / 2;
      scroller.scrollTop = start + (end - start) * eased;
      if (t < 1) scrollAnimation = requestAnimationFrame(turn);
      else {
        scrollAnimation = null;
        scroller.scrollTop = end;
        scroller.classList.remove('is-turning');
        updatePosition();
      }
    };
    scrollAnimation = requestAnimationFrame(turn);
  }
  const search = window.OURS_SEARCH;
  const searchInput = $('#day-search');
  const searchIndexes = new Map(events.map(event => [event.id, search.indexEvent(event, photos)]));
  let composing = false;
  let lastCompositionEnd = -Infinity;
  function renderDaySearch() {
    const query = searchInput.value.trim();
    const matches = query ? events.filter(event => search.matches(searchIndexes.get(event.id), query)) : [];
    const results = $('#search-results');
    results.replaceChildren();
    results.hidden = !query || !matches.length;
    $('#search-empty').hidden = !query || matches.length > 0;
    for (const event of matches) {
      const row = make('button', 'day-result');
      row.type = 'button';
      const label = make('span');
      label.append(make('span', 'result-date', event.date.replaceAll('-', '.')), make('span', 'result-title', event.title));
      row.append(label, make('span', 'result-arrow', '↗'));
      row.addEventListener('click', () => {
        const index = slides.findIndex(slide => slide.dataset.eventId === event.id);
        if (index >= 0) { goSlide(index); scroller.focus({ preventScroll: true }); }
      });
      results.append(row);
    }
  }
  searchInput.addEventListener('focus', () => { searchInput.placeholder = '日期、地点、关键词…'; });
  searchInput.addEventListener('blur', () => { searchInput.placeholder = ''; });
  searchInput.addEventListener('compositionstart', () => { composing = true; });
  searchInput.addEventListener('compositionend', () => {
    composing = false;
    lastCompositionEnd = performance.now();
    renderDaySearch();
  });
  searchInput.addEventListener('input', event => {
    if (!composing && !event.isComposing) renderDaySearch();
  });
  searchInput.addEventListener('keydown', event => {
    if (search.shouldSubmit(event, composing, performance.now() - lastCompositionEnd)) {
      event.preventDefault();
      $('#search-results button')?.click();
    }
  });
  renderDaySearch();
  $('.intro-next').addEventListener('click', () => goSlide(1));
  let pending = false;
  scroller.addEventListener('scroll', () => {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => { updatePosition(); pending = false; });
  }, { passive: true });

  // One wheel gesture advances one slide; allow the result list to scroll independently.
  let lastWheel = 0;
  let wheelTotal = 0;
  let gestureConsumed = false;
  let lockedUntil = 0;
  scroller.addEventListener('wheel', event => {
    if (event.ctrlKey || Math.abs(event.deltaX) > Math.abs(event.deltaY) || document.querySelector('dialog[open]')) return;
    const resultList = event.target.closest('.search-results');
    if (resultList && resultList.scrollHeight > resultList.clientHeight) return;
    if (event.target.closest('input')) return;
    event.preventDefault();
    if (scrollAnimation !== null) return;
    const at = performance.now();
    if (at - lastWheel > 200) { wheelTotal = 0; gestureConsumed = false; }
    lastWheel = at;
    if (gestureConsumed || at < lockedUntil) return;
    wheelTotal += event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? scroller.clientHeight : 1);
    if (Math.abs(wheelTotal) >= 35) {
      gestureConsumed = true;
      lockedUntil = at + 1000;
      goSlide(nearestSlide() + (wheelTotal > 0 ? 1 : -1));
    }
  }, { passive: false });
  document.addEventListener('keydown', event => {
    if (scroller.hidden || document.querySelector('dialog[open]') || event.target.closest('input,textarea,select,.day-search')) return;
    if (event.key === ' ' && event.target.closest('button,a')) return;
    let target;
    if (['ArrowDown', 'PageDown', ' '].includes(event.key)) target = nearestSlide() + 1;
    else if (['ArrowUp', 'PageUp'].includes(event.key)) target = nearestSlide() - 1;
    else if (event.key === 'Home') target = 0;
    else if (event.key === 'End') target = slides.length - 1;
    else return;
    event.preventDefault();
    goSlide(target);
  });
  function route() {
    cancelPageTurn();
    const id = ['home', 'wishes', 'stars'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'home';
    document.querySelectorAll('.page').forEach(page => { page.hidden = page.id !== 'page-' + id; });
    document.querySelectorAll('[data-page]').forEach(link => {
      if (link.dataset.page === id) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    document.body.classList.toggle('is-home', id === 'home');
    $('#slide-position').hidden = id !== 'home';
    document.title = `ours.ooo · ${{ home: 'Home', wishes: 'Wishes', stars: 'Twinkles' }[id]}`;
    window.scrollTo(0, 0);
    if (id === 'home') { scroller.scrollTo({ top: 0, behavior: 'instant' }); updatePosition(); }
  }
  window.addEventListener('hashchange', route);
  document.querySelectorAll('a[href="#home"]').forEach(link => {
    link.addEventListener('click', event => {
      if (!location.hash || location.hash === '#home') {
        event.preventDefault();
        goSlide(0);
      }
    });
  });
  window.addEventListener('resize', () => {
    digits.forEach(stopPaper);
    cancelPageTurn();
    if (!scroller.hidden) { scroller.scrollTo({ top: slideTop(slides[activeSlide]), behavior: 'instant' }); updatePosition(); }
  });
  scroller.addEventListener('pointerdown', event => {
    if (event.pointerType === 'touch') cancelPageTurn();
  }, { passive: true });
  route();
  animateDays();
})();
